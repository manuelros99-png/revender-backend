fetch("http://127.0.0.1:5057/")
  .then((r) => (r.ok ? r.json() : Promise.reject()))
  .then(() => {
    const el = document.getElementById("backend-status");
    el.textContent = "conectado";
    el.className = "ok";
  })
  .catch(() => {
    const el = document.getElementById("backend-status");
    el.textContent = "no responde";
    el.className = "err";
  });
