// Corre en autos.mercadolibre.com.ar y similares.
// MELI hace full page reload en cada paginación, así que este script
// solo maneja UNA página por instancia: extrae listings del DOM y se los
// pasa al background. No usa la API de MELI (requiere auth), scrapea
// directamente lo que el usuario ve en pantalla.

(function () {
  const PAGE_LOAD_WAIT_MS = 2000;

  const BLOCK_MARKERS = [
    "ingresá a tu cuenta", "ingresa a tu cuenta",
    "para continuar, inicia sesión",
    "verificá que no eres un robot", "verifica que no eres un robot",
  ];

  function looksBlocked() {
    const text = (document.body.innerText || "").toLowerCase();
    return (
      !!document.querySelector('input[type="password"]') ||
      !!document.querySelector('iframe[src*="captcha" i], [class*="captcha" i]') ||
      BLOCK_MARKERS.some((m) => text.includes(m))
    );
  }

  function looksEmpty() {
    const text = (document.body.innerText || "").toLowerCase();
    return text.includes("no encontramos resultados") || text.includes("no hay resultados");
  }

  function parsePrice(card) {
    const symbol = (card.querySelector('.andes-money-amount__currency-symbol')?.textContent || "").trim();
    const fraction = (card.querySelector('.andes-money-amount__fraction')?.textContent || "")
      .replace(/\./g, "").replace(/,/g, ".").trim();
    const cents = (card.querySelector('.andes-money-amount__cents')?.textContent || "").trim();
    const raw = cents ? `${fraction}.${cents}` : fraction;
    const price = raw ? parseFloat(raw) : null;
    const currency = symbol === "U$S" || symbol === "US$" ? "USD" : "ARS";
    return { price, currency };
  }

  function parseAttrs(card) {
    let year = null;
    let km = null;

    // Intento 1: selectores específicos de atributos
    const items = Array.from(
      card.querySelectorAll(
        '.poly-attributes-list__item, .ui-search-card-attributes__attribute, ' +
        '[class*="attributes"] li, [class*="attributes"] span, [class*="attribute"] li'
      )
    ).map((el) => el.textContent.trim());

    for (const item of items) {
      if (!year && /^(19|20)\d{2}$/.test(item)) {
        year = parseInt(item, 10);
      }
      if (!km && /km/i.test(item)) {
        const digits = item.replace(/\./g, "").replace(/,/g, "").replace(/[^\d]/g, "");
        if (digits) km = parseInt(digits, 10);
      }
    }

    // Intento 2: extraer del texto completo de la card (fallback robusto)
    if (!year || !km) {
      const text = card.innerText || "";

      if (!km) {
        // "48.000 km" o "48,000 km" o "48000 km"
        const kmMatch = text.match(/(\d[\d.,]*)\s*km\b/i);
        if (kmMatch) {
          km = parseInt(kmMatch[1].replace(/\./g, "").replace(/,/g, ""), 10);
        }
      }

      if (!year) {
        // Año standalone: "2019" "2022" etc., no precedido por más dígitos
        const yearMatches = [...text.matchAll(/\b(20\d{2})\b/g)];
        for (const m of yearMatches) {
          const y = parseInt(m[1], 10);
          if (y >= 2000 && y <= 2030) { year = y; break; }
        }
      }
    }

    return { year, km };
  }

  function collectListings() {
    const cards = Array.from(document.querySelectorAll("li.ui-search-layout__item"));
    const seen = new Set();
    const listings = [];

    for (const card of cards) {
      const link = card.querySelector('a[href*="mercadolibre.com.ar/MLA"]');
      if (!link) continue;

      const url = link.href.split("?")[0].split("#")[0];
      if (seen.has(url)) continue;
      seen.add(url);

      const mlaMatch = url.match(/MLA-?(\d+)/i);
      if (!mlaMatch) continue;

      const title = (
        card.querySelector(
          ".poly-component__title, a.poly-card__portada + div a, .ui-search-item__title, h2, h3"
        )?.textContent || ""
      ).trim();

      const { price, currency } = parsePrice(card);
      const { year, km } = parseAttrs(card);

      const location = (
        card.querySelector(
          ".poly-component__location, .ui-search-item__location, [class*='location']"
        )?.textContent || ""
      ).trim();

      const imageUrl = card.querySelector("img")?.src || null;

      listings.push({
        title,
        price,
        currency,
        year,
        km,
        location,
        url,
        imageUrl,
        sellerType: "unknown",
        rawText: title,
        attributes: {},
      });
    }

    return listings;
  }

  function findVersionFilterUrl(versionKeyword) {
    const keyword = versionKeyword.trim().toLowerCase();
    if (!keyword) return null;
    // MELI incluye el ID de versión en los links del sidebar como _SHORT*VERSION_XXXXXXX
    const links = Array.from(document.querySelectorAll('a[href*="_SHORT*VERSION_"]'));
    console.log("[Revender] Links de versión en sidebar:", links.length);
    for (const link of links) {
      const text = (link.textContent || "").trim().toLowerCase();
      // Solo match si el texto es no-vacío y es igual al keyword
      // o el label del sidebar contiene el keyword (ej. "seg turbo" contiene "seg").
      // NO usamos keyword.includes(text) porque un text="" o "s" matchearía cualquier keyword.
      if (text && (text === keyword || text.includes(keyword))) {
        console.log("[Revender] Versión encontrada en sidebar:", text, "→", link.href);
        return link.href.split("#")[0];
      }
    }
    return null;
  }

  function findNextPageUrl(listingsCount) {
    const currentFull = window.location.href;
    const currentBase = currentFull.split("?")[0].split("#")[0];
    const allLinks = Array.from(document.querySelectorAll("a[href]"));

    // Estrategia 1: <link rel="next"> en el <head> (SEO canonical) — ya incluye filtros
    const relNext = document.querySelector('link[rel="next"]');
    if (relNext?.href) return relNext.href;

    // Estrategia 2: cualquier link en la página con _Desde_N mayor al actual
    const currentOffset = (() => {
      const m = currentBase.match(/_Desde_(\d+)/);
      return m ? parseInt(m[1], 10) : 0;
    })();
    const offsetLink = allLinks
      .filter((a) => {
        const m = a.href.match(/_Desde_(\d+)/);
        return m && parseInt(m[1], 10) > currentOffset;
      })
      .sort((a, b) => {
        const ma = a.href.match(/_Desde_(\d+)/);
        const mb = b.href.match(/_Desde_(\d+)/);
        return parseInt(ma[1], 10) - parseInt(mb[1], 10);
      })[0];
    if (offsetLink) return offsetLink.href;

    // Estrategia 3: link "siguiente" solo si apunta a URL diferente
    const siguiente = allLinks.find(
      (el) => (el.textContent || "").trim().toLowerCase() === "siguiente"
    );
    if (siguiente && siguiente.href && siguiente.href !== currentFull) {
      return siguiente.href;
    }

    // Estrategia 4: construir la URL de la siguiente página directamente.
    // MELI usa _Desde_N_NoIndex_True donde N = 49 para pág 2, 97 para pág 3...
    // Los filtros van en el path (PciaId, año, dueno-directo), no en query params,
    // así que quedan preservados en slugBase automáticamente.
    if (listingsCount > 0) {
      const nextOffset = currentOffset === 0 ? 49 : currentOffset + 48;
      const slugBase = currentBase
        .replace(/_Desde_\d+/g, "")
        .replace(/_NoIndex_[A-Za-z]+/g, "")
        .replace(/\/+$/, "");
      return `${slugBase}_Desde_${nextOffset}_NoIndex_True`;
    }

    return null;
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function run(searchId, params) {
    console.log("[Revender] Iniciando en:", window.location.href);

    if (looksBlocked()) {
      chrome.runtime.sendMessage({
        type: "SCRAPE_BLOCKED",
        payload: { reason: "Mercado Libre mostró login/verificación. Iniciá sesión y reintentá." },
      });
      return;
    }

    await sleep(PAGE_LOAD_WAIT_MS);

    if (looksBlocked()) {
      chrome.runtime.sendMessage({
        type: "SCRAPE_BLOCKED",
        payload: { reason: "Mercado Libre mostró login/verificación. Iniciá sesión y reintentá." },
      });
      return;
    }

    const empty = looksEmpty();
    const listings = empty ? [] : collectListings();

    // En la búsqueda complementaria (listado.mercadolibre.com.ar) no buscamos filtro
    // de versión en el sidebar — es una búsqueda de texto libre, sin filtros estructurados.
    const isTextSearch = window.location.hostname === "listado.mercadolibre.com.ar";

    // Si el usuario pidió una versión específica y la URL actual no la tiene,
    // buscamos el filtro en el sidebar de MELI para obtener la URL con el ID interno.
    const versionRequested = (params?.version || "").trim();
    const versionInUrl = window.location.href.includes("_SHORT*VERSION_");
    let nextUrl;

    if (versionRequested && !versionInUrl && !isTextSearch) {
      const versionFilterUrl = findVersionFilterUrl(versionRequested);
      if (versionFilterUrl) {
        console.log("[Revender] Filtro de versión detectado en sidebar:", versionFilterUrl);
        nextUrl = versionFilterUrl; // reiniciamos desde pág 1 filtrada por versión
      } else {
        console.log("[Revender] No se encontró filtro de versión en sidebar para:", versionRequested);
        nextUrl = empty ? null : findNextPageUrl(listings.length);
      }
    } else {
      nextUrl = empty ? null : findNextPageUrl(listings.length);
    }

    console.log("[Revender] Listings en esta página:", listings.length, "| Siguiente:", nextUrl);
    if (listings.length > 0) {
      const s = listings[0];
      console.log("[Revender] Ejemplo →", "title:", s.title, "| year:", s.year, "| km:", s.km, "| price:", s.price, s.currency, "| loc:", s.location);
    }

    chrome.runtime.sendMessage(
      { type: "PAGE_SCRAPED", payload: { searchId, listings, nextUrl } },
      (ack) => console.log("[Revender] PAGE_SCRAPED ack:", ack, chrome.runtime.lastError?.message)
    );
  }

  console.log("[Revender] content_meli.js cargado:", window.location.href);

  chrome.runtime.sendMessage({ type: "WHOAMI" }, (resp) => {
    console.log("[Revender] WHOAMI:", resp, chrome.runtime.lastError?.message);
    if (resp?.searchId) run(resp.searchId, resp.params);
  });
})();
