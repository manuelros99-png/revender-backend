# Extensión "Revender" — instalación

Esta extensión solo actúa cuando creás una búsqueda desde el dashboard.
Abre una pestaña real de Mercado Libre (con tu sesión, tu red), lee lo que
ya está visible en pantalla, y se detiene si aparece login/captcha. No hace
nada en segundo plano por su cuenta.

## Instalación (modo desarrollador)

1. Abrí Chrome y entrá a `chrome://extensions`.
2. Activá **"Modo de desarrollador"** (switch arriba a la derecha).
3. Clic en **"Cargar descomprimida"** / **"Load unpacked"**.
4. Seleccioná la carpeta `extension/` de este proyecto.
5. Debería aparecer "Revender - Asistente de búsqueda" en la lista.

## Antes de usarla

El backend local tiene que estar corriendo (ver `backend/README.md`):

```bash
cd backend
source venv/bin/activate
python app.py
```

El dashboard se abre en `http://127.0.0.1:5057/dashboard`.

## Cómo probar que funciona

1. Con el backend corriendo y la extensión cargada, abrí `http://127.0.0.1:5057/dashboard`.
2. En la pestaña "Buscar", completá marca/modelo y clic en **"🔎 Buscar en Mercado Libre"**.
3. Se abre una pestaña nueva con la búsqueda en Mercado Libre.
4. A los pocos segundos, volvé al dashboard — debería mostrar el estado cambiando (buscando → analizando → completada) y las oportunidades en la pestaña correspondiente.

## Si no funciona

- **No aparece el botón de la extensión / el dashboard avisa "no detecté la extensión"**: revisá que esté habilitada en `chrome://extensions`.
- **Queda en "buscando" para siempre**: revisá la consola de la pestaña de Mercado Libre (clic derecho → Inspeccionar) por errores. Es posible que MELI haya cambiado el HTML y los selectores de `content_meli.js` necesiten un ajuste.
- **Error "no se pudo conectar al backend"**: confirmá que `python app.py` esté corriendo en otra terminal.
- **Mercado Libre pide login/captcha**: es esperado que la búsqueda se detenga con un error — iniciá sesión manualmente en esa pestaña y reintentá.
