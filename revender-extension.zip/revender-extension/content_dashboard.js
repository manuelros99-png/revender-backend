// Puente entre la página del dashboard (revender.html) y la extensión.
// Corre en el "mundo aislado" de la extensión pero comparte el DOM con la página,
// así que puede escuchar/disparar CustomEvent en window sin exponer APIs de chrome.* a la página.

(function () {
  // Solo activarse si esta página es realmente el dashboard (evita correr en cualquier file://).
  if (!document.getElementById("btn-nueva-busqueda")) return;

  // Avisarle a la página que la extensión está instalada y lista.
  window.dispatchEvent(new CustomEvent("gonzalito:extension-ready"));

  function safeSend(message) {
    if (!chrome.runtime?.id) {
      // El contexto de la extensión fue invalidado (se recargó mientras la página estaba abierta).
      window.dispatchEvent(new CustomEvent("gonzalito:context-lost"));
      return;
    }
    try {
      chrome.runtime.sendMessage(message);
    } catch (_) {
      window.dispatchEvent(new CustomEvent("gonzalito:context-lost"));
    }
  }

  window.addEventListener("gonzalito:buscar", (e) => {
    safeSend({ type: "START_SEARCH", payload: e.detail });
  });

  window.addEventListener("gonzalito:precio-lookup", (e) => {
    safeSend({ type: "START_PRICE_LOOKUP", payload: e.detail });
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "GONZALITO_STATUS") {
      window.dispatchEvent(
        new CustomEvent("gonzalito:status", {
          detail: { searchId: msg.searchId, status: msg.status, message: msg.message },
        })
      );
    } else if (msg.type === "GONZALITO_RESULT") {
      window.dispatchEvent(
        new CustomEvent("gonzalito:resultado", {
          detail: { searchId: msg.searchId, result: msg.result },
        })
      );
    } else if (msg.type === "PRICE_LOOKUP_STATUS") {
      window.dispatchEvent(new CustomEvent("gonzalito:precio-status", { detail: { message: msg.message } }));
    } else if (msg.type === "PRICE_LOOKUP_RESULT") {
      window.dispatchEvent(new CustomEvent("gonzalito:precio-resultado", { detail: { listings: msg.listings } }));
    } else if (msg.type === "PRICE_LOOKUP_ERROR") {
      window.dispatchEvent(new CustomEvent("gonzalito:precio-error", { detail: { message: msg.message } }));
    }
  });
})();
