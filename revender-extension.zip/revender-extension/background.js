// Service worker: coordina dashboard <-> pestaña MELI <-> backend local.

const BACKEND = "https://web-production-d7112.up.railway.app";
const MAX_PAGES = 10;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_SEARCH") {
    handleStartSearch(msg.payload, sender.tab?.id)
      .then(() => sendResponse({ ack: true }))
      .catch((e) => sendResponse({ ack: false, error: e.message }));
    return true;
  } else if (msg.type === "START_PRICE_LOOKUP") {
    handleStartPriceLookup(msg.payload, sender.tab?.id)
      .then(() => sendResponse({ ack: true }))
      .catch((e) => sendResponse({ ack: false, error: e.message }));
    return true;
  } else if (msg.type === "WHOAMI") {
    handleWhoAmI(sender.tab?.id, sendResponse);
    return true;
  } else if (msg.type === "PAGE_SCRAPED") {
    handlePageScraped(msg.payload, sender.tab?.id)
      .then(() => sendResponse({ ack: true }))
      .catch((e) => sendResponse({ ack: false, error: e.message }));
    return true;
  } else if (msg.type === "SCRAPE_BLOCKED") {
    handleBlocked(msg.payload, sender.tab?.id)
      .then(() => sendResponse({ ack: true }))
      .catch(() => sendResponse({ ack: false }));
    return true;
  }
});

async function handleStartSearch(params, dashboardTabId) {
  try {
    const res = await fetch(`${BACKEND}/api/searches`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      notifyDashboard(dashboardTabId, {
        type: "GONZALITO_STATUS", searchId: null, status: "error",
        message: err.error || "El backend rechazó la búsqueda",
      });
      return;
    }
    const data = await res.json();
    notifyDashboard(dashboardTabId, {
      type: "GONZALITO_STATUS", searchId: data.searchId,
      status: "buscando", message: "Abriendo Mercado Libre...",
    });
    const tab = await chrome.tabs.create({ url: data.meliUrl, active: true });
    await chrome.storage.local.set({
      [`search_${data.searchId}`]: { dashboardTabId, params, meliUrlAlt: data.meliUrlAlt || null },
      [`tab_${tab.id}`]: data.searchId,
      [`pages_${data.searchId}`]: { allListings: [], page: 0, phase: "primary" },
    });
    console.log("[Revender BG] Búsqueda creada:", data.searchId, "Tab:", tab.id);
  } catch (e) {
    notifyDashboard(dashboardTabId, {
      type: "GONZALITO_STATUS", searchId: null, status: "error",
      message: "No se pudo conectar al backend (" + BACKEND + "): " + e.message,
    });
  }
}

async function handleStartPriceLookup(params, dashboardTabId) {
  try {
    const res = await fetch(`${BACKEND}/api/searches`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      notifyDashboard(dashboardTabId, {
        type: "PRICE_LOOKUP_ERROR",
        message: err.error || "El backend rechazó la consulta",
      });
      return;
    }
    const data = await res.json();
    notifyDashboard(dashboardTabId, {
      type: "PRICE_LOOKUP_STATUS", message: "Abriendo Mercado Libre...",
    });
    const tab = await chrome.tabs.create({ url: data.meliUrl, active: true });
    await chrome.storage.local.set({
      [`search_${data.searchId}`]: { dashboardTabId, params, lookupMode: true },
      [`tab_${tab.id}`]: data.searchId,
      [`pages_${data.searchId}`]: { allListings: [], page: 0, phase: "primary" },
    });
    console.log("[Revender BG] Price lookup:", data.searchId, "Tab:", tab.id);
  } catch (e) {
    notifyDashboard(dashboardTabId, {
      type: "PRICE_LOOKUP_ERROR",
      message: "No se pudo conectar al backend: " + e.message,
    });
  }
}

async function handleWhoAmI(tabId, sendResponse) {
  const stored = await chrome.storage.local.get(`tab_${tabId}`);
  const searchId = stored[`tab_${tabId}`] || null;
  if (!searchId) { sendResponse({ searchId: null }); return; }
  const meta = await chrome.storage.local.get(`search_${searchId}`);
  const params = meta[`search_${searchId}`]?.params || {};
  sendResponse({ searchId, params });
}

async function handlePageScraped({ searchId, listings, nextUrl }, tabId) {
  const keys = [`search_${searchId}`, `pages_${searchId}`];
  const stored = await chrome.storage.local.get(keys);
  const info = stored[`search_${searchId}`];
  const state = stored[`pages_${searchId}`] || { allListings: [], page: 0 };

  // Acumular listings nuevos (dedup por URL)
  const seen = new Set(state.allListings.map((l) => l.url));
  for (const listing of listings || []) {
    if (!seen.has(listing.url)) {
      seen.add(listing.url);
      state.allListings.push(listing);
    }
  }
  state.page++;

  // Modo valoración: una sola página, devolver precios al dashboard sin análisis
  if (info?.lookupMode) {
    await chrome.storage.local.remove([`pages_${searchId}`, `tab_${tabId}`, `search_${searchId}`]);
    chrome.tabs.remove(tabId).catch(() => {});
    notifyDashboard(info.dashboardTabId, {
      type: "PRICE_LOOKUP_RESULT",
      listings: state.allListings,
    });
    return;
  }

  console.log(
    `[Revender BG] ${state.phase} · Página ${state.page}/${MAX_PAGES} — acumulados: ${state.allListings.length} listings`
  );

  const hasAlt = !!info?.meliUrlAlt;
  const searchLabel = hasAlt
    ? (state.phase === "secondary" ? "Búsqueda 2/2" : "Búsqueda 1/2")
    : null;
  const msgPrefix = searchLabel ? `${searchLabel} · ` : "";
  notifyDashboard(info?.dashboardTabId, {
    type: "GONZALITO_STATUS", searchId,
    status: "buscando",
    message: `${msgPrefix}Página ${state.page}/${MAX_PAGES}: ${state.allListings.length} publicaciones encontradas...`,
  });

  if (nextUrl && state.page < MAX_PAGES) {
    await chrome.storage.local.set({ [`pages_${searchId}`]: state });
    chrome.tabs.update(tabId, { url: nextUrl });
  } else if (state.phase === "primary" && info?.meliUrlAlt) {
    state.phase = "secondary";
    state.page = 0;
    await chrome.storage.local.set({ [`pages_${searchId}`]: state });
    notifyDashboard(info?.dashboardTabId, {
      type: "GONZALITO_STATUS", searchId,
      status: "buscando",
      message: `Búsqueda 2/2: buscando publicaciones sin filtros... (${state.allListings.length} encontradas hasta ahora)`,
    });
    chrome.tabs.update(tabId, { url: info.meliUrlAlt });
  } else {
    await chrome.storage.local.remove([`pages_${searchId}`, `tab_${tabId}`, `search_${searchId}`]);
    await postToBackend(searchId, state.allListings, info);
  }
}

async function postToBackend(searchId, allListings, info) {
  console.log("[Revender BG] Enviando", allListings.length, "listings al backend");

  if (allListings.length === 0) {
    await setError(searchId, info, "No se encontraron publicaciones en los resultados de Mercado Libre.");
    return;
  }

  notifyDashboard(info?.dashboardTabId, {
    type: "GONZALITO_STATUS", searchId, status: "analizando",
    message: `Analizando ${allListings.length} publicaciones...`,
  });

  try {
    const res = await fetch(`${BACKEND}/api/searches/${searchId}/listings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listings: allListings }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      await setError(searchId, info, `Error del backend (${res.status}): ${text.slice(0, 200)}`);
      return;
    }
    const result = await res.json();
    console.log("[Revender BG] Backend respondió:", result.status,
      "oportunidades:", result.oportunidades?.length,
      "descartadas:", result.descartadas?.length);
    notifyDashboard(info?.dashboardTabId, { type: "GONZALITO_RESULT", searchId, result });
  } catch (e) {
    await setError(searchId, info, "Error al enviar resultados al backend: " + e.message);
  }
}

async function setError(searchId, info, message) {
  console.error("[Revender BG] Error:", message);
  await fetch(`${BACKEND}/api/searches/${searchId}/status`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: "error", message }),
  }).catch(() => {});
  notifyDashboard(info?.dashboardTabId, {
    type: "GONZALITO_STATUS", searchId, status: "error", message,
  });
}

async function handleBlocked({ reason }, tabId) {
  const stored = await chrome.storage.local.get(`tab_${tabId}`);
  const searchId = stored[`tab_${tabId}`];
  if (!searchId) return;
  const meta = await chrome.storage.local.get(`search_${searchId}`);
  await setError(searchId, meta[`search_${searchId}`], reason);
}

function notifyDashboard(tabId, message) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, message).catch(() => {});
}
